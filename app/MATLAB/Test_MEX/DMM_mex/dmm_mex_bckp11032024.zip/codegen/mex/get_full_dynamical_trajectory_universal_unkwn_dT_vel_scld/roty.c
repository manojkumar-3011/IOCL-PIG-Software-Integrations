/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * roty.c
 *
 * Code generation for function 'roty'
 *
 */

/* Include files */
#include "roty.h"
#include "cosd.h"
#include "get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld_data.h"
#include "rt_nonfinite.h"
#include "sind.h"
#include "mwmathutil.h"

/* Variable Definitions */
static emlrtRSInfo h_emlrtRSI = {
    31,     /* lineNo */
    "roty", /* fcnName */
    "C:\\Program Files\\MATLAB\\R2021b\\toolbox\\phased\\phased\\roty.m" /* pathName
                                                                          */
};

/* Function Definitions */
void roty(const emlrtStack *sp, real_T beta, real_T rotmat[9])
{
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack st;
  real_T b_rotmat_tmp;
  real_T rotmat_tmp;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &h_emlrtRSI;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  b_st.site = &f_emlrtRSI;
  c_st.site = &g_emlrtRSI;
  if (muDoubleScalarIsInf(beta) || muDoubleScalarIsNaN(beta)) {
    emlrtErrorWithMessageIdR2018a(
        &c_st, &b_emlrtRTEI, "Coder:toolbox:ValidateattributesexpectedFinite",
        "MATLAB:roty:expectedFinite", 3, 4, 4, "BETA");
  }
  c_st.site = &g_emlrtRSI;
  if (muDoubleScalarIsNaN(beta)) {
    emlrtErrorWithMessageIdR2018a(
        &c_st, &c_emlrtRTEI, "Coder:toolbox:ValidateattributesexpectedNonNaN",
        "MATLAB:roty:expectedNonNaN", 3, 4, 4, "BETA");
  }
  rotmat_tmp = beta;
  b_sind(&rotmat_tmp);
  b_rotmat_tmp = beta;
  b_cosd(&b_rotmat_tmp);
  rotmat[0] = b_rotmat_tmp;
  rotmat[3] = 0.0;
  rotmat[6] = rotmat_tmp;
  rotmat[1] = 0.0;
  rotmat[4] = 1.0;
  rotmat[7] = 0.0;
  rotmat[2] = -rotmat_tmp;
  rotmat[5] = 0.0;
  rotmat[8] = b_rotmat_tmp;
}

/* End of code generation (roty.c) */
