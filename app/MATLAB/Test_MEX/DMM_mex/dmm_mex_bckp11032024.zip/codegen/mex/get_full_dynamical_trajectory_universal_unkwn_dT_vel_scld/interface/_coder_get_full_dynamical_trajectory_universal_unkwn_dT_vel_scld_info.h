/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld_info.h
 *
 * Code generation for function
 * 'get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld'
 *
 */

#pragma once

/* Include files */
#include "mex.h"

/* Function Declarations */
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

/* End of code generation
 * (_coder_get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld_info.h) */
