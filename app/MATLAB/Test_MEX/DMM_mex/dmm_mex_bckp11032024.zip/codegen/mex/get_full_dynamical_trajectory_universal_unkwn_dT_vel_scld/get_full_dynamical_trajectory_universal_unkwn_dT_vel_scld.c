/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld.c
 *
 * Code generation for function
 * 'get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld'
 *
 */

/* Include files */
#include "get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld.h"
#include "cosd.h"
#include "expm.h"
#include "get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld_data.h"
#include "quat2rotm.h"
#include "rotm2quat.h"
#include "rotx.h"
#include "roty.h"
#include "rt_nonfinite.h"
#include "sind.h"
#include "mwmathutil.h"
#include <math.h>
#include <string.h>

/* Variable Definitions */
static emlrtRSInfo emlrtRSI = {
    21,                                                          /* lineNo */
    "get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld", /* fcnName */
    "F:\\Academic\\Dropbox\\Recent\\WorkQC\\Experiments for "
    "transfer\\FSP_ver0_speed\\Test_MEX\\DMM_mex\\get_full_dynamical_"
    "trajectory_univers"
    "al_unkwn_dT_vel_scld.m" /* pathName */
};

static emlrtRSInfo b_emlrtRSI = {
    47,                                                          /* lineNo */
    "get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld", /* fcnName */
    "F:\\Academic\\Dropbox\\Recent\\WorkQC\\Experiments for "
    "transfer\\FSP_ver0_speed\\Test_MEX\\DMM_mex\\get_full_dynamical_"
    "trajectory_univers"
    "al_unkwn_dT_vel_scld.m" /* pathName */
};

static emlrtRSInfo c_emlrtRSI = {
    53,                                                          /* lineNo */
    "get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld", /* fcnName */
    "F:\\Academic\\Dropbox\\Recent\\WorkQC\\Experiments for "
    "transfer\\FSP_ver0_speed\\Test_MEX\\DMM_mex\\get_full_dynamical_"
    "trajectory_univers"
    "al_unkwn_dT_vel_scld.m" /* pathName */
};

static emlrtRSInfo d_emlrtRSI = {
    54,                                                          /* lineNo */
    "get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld", /* fcnName */
    "F:\\Academic\\Dropbox\\Recent\\WorkQC\\Experiments for "
    "transfer\\FSP_ver0_speed\\Test_MEX\\DMM_mex\\get_full_dynamical_"
    "trajectory_univers"
    "al_unkwn_dT_vel_scld.m" /* pathName */
};

static emlrtRSInfo kd_emlrtRSI = {
    22,             /* lineNo */
    "pig_dynamics", /* fcnName */
    "F:\\Academic\\Dropbox\\Recent\\WorkQC\\Experiments for "
    "transfer\\FSP_ver0_speed\\Test_MEX\\DMM_mex\\pig_dynamics.m" /* pathName */
};

static emlrtRSInfo ld_emlrtRSI = {
    31,             /* lineNo */
    "pig_dynamics", /* fcnName */
    "F:\\Academic\\Dropbox\\Recent\\WorkQC\\Experiments for "
    "transfer\\FSP_ver0_speed\\Test_MEX\\DMM_mex\\pig_dynamics.m" /* pathName */
};

static emlrtRSInfo md_emlrtRSI = {
    32,             /* lineNo */
    "pig_dynamics", /* fcnName */
    "F:\\Academic\\Dropbox\\Recent\\WorkQC\\Experiments for "
    "transfer\\FSP_ver0_speed\\Test_MEX\\DMM_mex\\pig_dynamics.m" /* pathName */
};

static emlrtRSInfo nd_emlrtRSI = {
    51,     /* lineNo */
    "expm", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" /* pathName
                                                                        */
};

static emlrtRSInfo qd_emlrtRSI = {
    61,     /* lineNo */
    "expm", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" /* pathName
                                                                        */
};

static emlrtRTEInfo emlrtRTEI = {
    62,     /* lineNo */
    13,     /* colNo */
    "expm", /* fName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" /* pName
                                                                        */
};

/* Function Definitions */
void get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld(
    const emlrtStack *sp, const real_T new_agb_j[21], const real_T indices[106],
    const real_T g_all[318], const real_T w_all[318], real_T downsampling,
    const real_T start_gps[3], const real_T best_initial_orientation[4],
    real_T q_dot[424], real_T q[424], real_T v_dot[318], real_T v[318],
    real_T p_gen[318], real_T odo_gen[106], real_T acc_ef[318])
{
  static const real_T theta[5] = {0.01495585217958292, 0.253939833006323,
                                  0.95041789961629319, 2.097847961257068,
                                  5.3719203511481517};
  static const real_T d_b[3] = {0.0, 0.0, 9.81};
  static const real_T dv2[3] = {0.0, 0.0, -9.81};
  static const int8_T iv[6] = {1, 2, 3, 7, 8, 9};
  static const uint8_T uv[5] = {3U, 5U, 7U, 9U, 13U};
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack st;
  real_T b_x[17];
  real_T dv1[17];
  real_T x[17];
  real_T b_y[16];
  real_T c_a[16];
  real_T Sx_n_omega_ie[9];
  real_T a[9];
  real_T b[9];
  real_T b_a[9];
  real_T b_b[9];
  real_T c_b[9];
  real_T params[8];
  real_T u[6];
  real_T q0[4];
  real_T d_a[3];
  real_T dv[3];
  real_T e_a[3];
  real_T w_b[3];
  real_T G_func_tmp;
  real_T absx;
  real_T absxk;
  real_T absxk_tmp_tmp;
  real_T c_x_tmp;
  real_T d;
  real_T dT;
  real_T d_x_tmp;
  real_T e_x_tmp;
  real_T normA;
  real_T s;
  real_T scale;
  real_T t;
  real_T v_scl_idx_0;
  real_T v_scl_idx_1;
  real_T v_scl_idx_2;
  real_T y;
  real_T y_tmp;
  int32_T absxk_tmp;
  int32_T b_x_tmp;
  int32_T eint;
  int32_T i;
  int32_T i1;
  int32_T ix;
  int32_T j;
  int32_T p_gen_tmp;
  int32_T s_tmp;
  int32_T x_tmp;
  int8_T n;
  boolean_T exitg1;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  /*      east_radius_of_earth = 6378100; % equatorial (Wikipedia)  */
  /*      north_radius_of_earth = 6356800; % polar (Wikipedia)  */
  /*      manifld_factr_en = 1; % manifold is default  */
  /*      rotn_factr_en = 1; % earth rotation is default value  */
  /*  radians per second [=7.292115e-5*180/pi*86400 = 360.9856]  */
  /*   */
  /*  acc_gain_mat = diag(agb_now(2:4));  */
  /*  gyro_gain_mat = diag(agb_now(8:10));  */
  for (i = 0; i < 6; i++) {
    params[i] = new_agb_j[iv[i]];
  }
  params[6] = new_agb_j[20] * downsampling / 10.0;
  params[7] = new_agb_j[0];
  /*  q0 = obj.best_initial_orientation + agb_now(14:17);  */
  st.site = &emlrtRSI;
  rotx(&st, start_gps[1], a);
  st.site = &emlrtRSI;
  roty(&st, start_gps[0], b);
  st.site = &emlrtRSI;
  quat2rotm(&st, best_initial_orientation, b_b);
  for (i = 0; i < 3; i++) {
    y_tmp = a[i];
    d = a[i + 3];
    s = a[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      b_a[i + 3 * i1] =
          (y_tmp * b[3 * i1] + d * b[3 * i1 + 1]) + s * b[3 * i1 + 2];
    }
    y_tmp = b_a[i];
    d = b_a[i + 3];
    s = b_a[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      a[i + 3 * i1] =
          (y_tmp * b_b[3 * i1] + d * b_b[3 * i1 + 1]) + s * b_b[3 * i1 + 2];
    }
  }
  st.site = &emlrtRSI;
  rotm2quat(&st, a, q0);
  dT = new_agb_j[20] * (indices[1] - indices[0]) * downsampling / 10.0;
  /*   */
  memset(&q_dot[0], 0, 424U * sizeof(real_T));
  memset(&q[0], 0, 424U * sizeof(real_T));
  memset(&v_dot[0], 0, 318U * sizeof(real_T));
  memset(&v[0], 0, 318U * sizeof(real_T));
  memset(&p_gen[0], 0, 318U * sizeof(real_T));
  memset(&odo_gen[0], 0, 106U * sizeof(real_T));
  memset(&acc_ef[0], 0, 318U * sizeof(real_T));
  q[0] = q0[0] + new_agb_j[13];
  q[1] = q0[1] + new_agb_j[14];
  q[2] = q0[2] + new_agb_j[15];
  q[3] = q0[3] + new_agb_j[16];
  /*  <-- normalized later  */
  /*   */
  v[0] = new_agb_j[17];
  p_gen[0] = start_gps[0];
  v[1] = new_agb_j[18];
  p_gen[1] = start_gps[1];
  v[2] = new_agb_j[19];
  p_gen[2] = start_gps[2];
  /*   */
  Sx_n_omega_ie[0] = 0.0;
  Sx_n_omega_ie[6] = 0.0;
  Sx_n_omega_ie[4] = 0.0;
  Sx_n_omega_ie[2] = -0.0;
  Sx_n_omega_ie[8] = 0.0;
  dv[0] = 0.0;
  dv[1] = 0.0;
  for (ix = 0; ix < 105; ix++) {
    scale = 3.3121686421112381E-170;
    absxk_tmp = ix << 2;
    normA = q[absxk_tmp];
    absxk = muDoubleScalarAbs(normA);
    if (absxk > 3.3121686421112381E-170) {
      y = 1.0;
      scale = absxk;
    } else {
      t = absxk / 3.3121686421112381E-170;
      y = t * t;
    }
    absx = q[absxk_tmp + 1];
    absxk = muDoubleScalarAbs(absx);
    if (absxk > scale) {
      t = scale / absxk;
      y = y * t * t + 1.0;
      scale = absxk;
    } else {
      t = absxk / scale;
      y += t * t;
    }
    s = q[absxk_tmp + 2];
    absxk = muDoubleScalarAbs(s);
    if (absxk > scale) {
      t = scale / absxk;
      y = y * t * t + 1.0;
      scale = absxk;
    } else {
      t = absxk / scale;
      y += t * t;
    }
    absxk_tmp_tmp = q[absxk_tmp + 3];
    absxk = muDoubleScalarAbs(absxk_tmp_tmp);
    if (absxk > scale) {
      t = scale / absxk;
      y = y * t * t + 1.0;
      scale = absxk;
    } else {
      t = absxk / scale;
      y += t * t;
    }
    y = scale * muDoubleScalarSqrt(y);
    /*  dT =
     * obj.downsampling*(indices(ix)-indices(ix-1))/obj.sampling_frequency;  */
    /*   */
    x[0] = odo_gen[ix];
    x[1] = p_gen[3 * ix];
    x_tmp = 3 * ix + 1;
    x[2] = p_gen[x_tmp];
    b_x_tmp = 3 * ix + 2;
    x[3] = p_gen[b_x_tmp];
    x[4] = normA / y;
    x[5] = absx / y;
    x[6] = s / y;
    x[7] = absxk_tmp_tmp / y;
    c_x_tmp = v[3 * ix];
    x[8] = c_x_tmp;
    x[11] = new_agb_j[4];
    x[14] = new_agb_j[10];
    u[0] = g_all[3 * ix];
    u[3] = w_all[3 * ix];
    d_x_tmp = v[x_tmp];
    x[9] = d_x_tmp;
    x[12] = new_agb_j[5];
    x[15] = new_agb_j[11];
    u[1] = g_all[x_tmp];
    u[4] = w_all[x_tmp];
    e_x_tmp = v[b_x_tmp];
    x[10] = e_x_tmp;
    x[13] = new_agb_j[6];
    x[16] = new_agb_j[12];
    u[2] = g_all[b_x_tmp];
    u[5] = w_all[b_x_tmp];
    st.site = &b_emlrtRSI;
    /*  equatorial (Wikipedia)  */
    /*  polar (Wikipedia)  */
    /*  manifold is default  */
    /*  earth rotation is default value  */
    /*  radians per second [=7.292115e-5*180/pi*86400 = 360.9856]  */
    /*  o <--x(1) | p <--x(2:4) | q <--x(5:8) | v <--x(9:11) | bs <--x(12:17)
     * [+] imu_a <--u(1:3) | imu_w <--u(4:6)   */
    v_scl_idx_0 = params[7] * c_x_tmp;
    v_scl_idx_1 = params[7] * d_x_tmp;
    v_scl_idx_2 = params[7] * e_x_tmp;
    G_func_tmp = x[1];
    b_cosd(&G_func_tmp);
    w_b[0] = params[3] * u[3] + new_agb_j[10];
    w_b[1] = params[4] * u[4] + new_agb_j[11];
    w_b[2] = params[5] * u[5] + new_agb_j[12];
    b_y[0] = 0.0 * params[6];
    absxk_tmp_tmp = 0.5 * -w_b[0] * params[6];
    b_y[4] = absxk_tmp_tmp;
    normA = 0.5 * -w_b[1] * params[6];
    b_y[8] = normA;
    absx = 0.5 * -w_b[2] * params[6];
    b_y[12] = absx;
    s = 0.5 * w_b[0] * params[6];
    b_y[1] = s;
    b_y[5] = 0.0 * params[6];
    y_tmp = 0.5 * w_b[2] * params[6];
    b_y[9] = y_tmp;
    b_y[13] = normA;
    normA = 0.5 * w_b[1] * params[6];
    b_y[2] = normA;
    b_y[6] = absx;
    b_y[10] = 0.0 * params[6];
    b_y[14] = s;
    b_y[3] = y_tmp;
    b_y[7] = normA;
    b_y[11] = absxk_tmp_tmp;
    b_y[15] = 0.0 * params[6];
    b_st.site = &kd_emlrtRSI;
    normA = 0.0;
    j = 0;
    exitg1 = false;
    while ((!exitg1) && (j < 4)) {
      s_tmp = j << 2;
      s = ((muDoubleScalarAbs(b_y[s_tmp]) + muDoubleScalarAbs(b_y[s_tmp + 1])) +
           muDoubleScalarAbs(b_y[s_tmp + 2])) +
          muDoubleScalarAbs(b_y[s_tmp + 3]);
      if (muDoubleScalarIsNaN(s)) {
        normA = rtNaN;
        exitg1 = true;
      } else {
        if (s > normA) {
          normA = s;
        }
        j++;
      }
    }
    if (normA <= 5.3719203511481517) {
      s_tmp = 0;
      exitg1 = false;
      while ((!exitg1) && (s_tmp < 5)) {
        if (normA <= theta[s_tmp]) {
          c_st.site = &nd_emlrtRSI;
          PadeApproximantOfDegree(&c_st, b_y, uv[s_tmp], c_a);
          exitg1 = true;
        } else {
          s_tmp++;
        }
      }
    } else {
      absxk_tmp_tmp = normA / 5.3719203511481517;
      if ((!muDoubleScalarIsInf(absxk_tmp_tmp)) &&
          (!muDoubleScalarIsNaN(absxk_tmp_tmp))) {
        absxk_tmp_tmp = frexp(absxk_tmp_tmp, &eint);
        s_tmp = eint;
      } else {
        s_tmp = 0;
      }
      s = s_tmp;
      if (absxk_tmp_tmp == 0.5) {
        s = (real_T)s_tmp - 1.0;
      }
      y = muDoubleScalarPower(2.0, s);
      for (i = 0; i < 16; i++) {
        b_y[i] /= y;
      }
      c_st.site = &qd_emlrtRSI;
      PadeApproximantOfDegree(&c_st, b_y, 13U, c_a);
      i = (int32_T)s;
      emlrtForLoopVectorCheckR2021a(1.0, 1.0, s, mxDOUBLE_CLASS, (int32_T)s,
                                    &emlrtRTEI, &b_st);
      for (j = 0; j < i; j++) {
        for (i1 = 0; i1 < 4; i1++) {
          for (p_gen_tmp = 0; p_gen_tmp < 4; p_gen_tmp++) {
            s_tmp = p_gen_tmp << 2;
            b_y[i1 + s_tmp] =
                ((c_a[i1] * c_a[s_tmp] + c_a[i1 + 4] * c_a[s_tmp + 1]) +
                 c_a[i1 + 8] * c_a[s_tmp + 2]) +
                c_a[i1 + 12] * c_a[s_tmp + 3];
          }
        }
        memcpy(&c_a[0], &b_y[0], 16U * sizeof(real_T));
      }
    }
    y_tmp = x[1];
    b_sind(&y_tmp);
    w_b[0] = 7.292115E-5 * G_func_tmp;
    w_b[2] = 7.292115E-5 * y_tmp;
    if (muDoubleScalarIsInf(x[1]) || muDoubleScalarIsNaN(x[1])) {
      absxk_tmp_tmp = rtNaN;
    } else {
      absxk_tmp_tmp = muDoubleScalarRem(x[1], 360.0);
      absx = muDoubleScalarAbs(absxk_tmp_tmp);
      if (absx > 180.0) {
        if (absxk_tmp_tmp > 0.0) {
          absxk_tmp_tmp -= 360.0;
        } else {
          absxk_tmp_tmp += 360.0;
        }
        absx = muDoubleScalarAbs(absxk_tmp_tmp);
      }
      if (absx <= 45.0) {
        absxk_tmp_tmp *= 0.017453292519943295;
        n = 0;
      } else if (absx <= 135.0) {
        if (absxk_tmp_tmp > 0.0) {
          absxk_tmp_tmp = 0.017453292519943295 * (absxk_tmp_tmp - 90.0);
          n = 1;
        } else {
          absxk_tmp_tmp = 0.017453292519943295 * (absxk_tmp_tmp + 90.0);
          n = -1;
        }
      } else if (absxk_tmp_tmp > 0.0) {
        absxk_tmp_tmp = 0.017453292519943295 * (absxk_tmp_tmp - 180.0);
        n = 2;
      } else {
        absxk_tmp_tmp = 0.017453292519943295 * (absxk_tmp_tmp + 180.0);
        n = -2;
      }
      absxk_tmp_tmp = muDoubleScalarTan(absxk_tmp_tmp);
      if ((n == 1) || (n == -1)) {
        s = 1.0 / absxk_tmp_tmp;
        absxk_tmp_tmp = -(1.0 / absxk_tmp_tmp);
        if (muDoubleScalarIsInf(absxk_tmp_tmp) && (n == 1)) {
          absxk_tmp_tmp = s;
        }
      }
    }
    y_tmp = 2.0 * w_b[0] + -d_x_tmp / (x[3] + 6.3781E+6);
    d = c_x_tmp / (x[3] + 6.3568E+6);
    s = 2.0 * w_b[2] + -d_x_tmp * absxk_tmp_tmp / (x[3] + 6.3781E+6);
    Sx_n_omega_ie[3] = -w_b[2];
    Sx_n_omega_ie[1] = w_b[2];
    Sx_n_omega_ie[7] = -w_b[0];
    Sx_n_omega_ie[5] = w_b[0];
    b_st.site = &ld_emlrtRSI;
    roty(&b_st, -x[1], a);
    b_st.site = &ld_emlrtRSI;
    rotx(&b_st, -x[2], b);
    b_st.site = &md_emlrtRSI;
    rotx(&b_st,
         -(dT * (((real_T)ix + 2.0) - 2.0)) * 7.292115E-5 * 180.0 /
             3.1415926535897931,
         b_b);
    b_st.site = &md_emlrtRSI;
    quat2rotm(&b_st, *(real_T(*)[4]) & x[4], c_b);
    /*  eul2rotm(flip(omega_ie(p)')*t) */
    scale = 3.3121686421112381E-170;
    absxk = muDoubleScalarAbs(v_scl_idx_0);
    if (absxk > 3.3121686421112381E-170) {
      y = 1.0;
      scale = absxk;
    } else {
      t = absxk / 3.3121686421112381E-170;
      y = t * t;
    }
    absxk = muDoubleScalarAbs(v_scl_idx_1);
    if (absxk > scale) {
      t = scale / absxk;
      y = y * t * t + 1.0;
      scale = absxk;
    } else {
      t = absxk / scale;
      y += t * t;
    }
    absxk = muDoubleScalarAbs(v_scl_idx_2);
    if (absxk > scale) {
      t = scale / absxk;
      y = y * t * t + 1.0;
      scale = absxk;
    } else {
      t = absxk / scale;
      y += t * t;
    }
    y = scale * muDoubleScalarSqrt(y);
    /*  [not needed] /norm(q_gen(q,bs,imu_w));  */
    for (i = 0; i < 3; i++) {
      absxk_tmp_tmp = a[i];
      normA = a[i + 3];
      absx = a[i + 6];
      for (i1 = 0; i1 < 3; i1++) {
        b_a[i + 3 * i1] = (absxk_tmp_tmp * b[3 * i1] + normA * b[3 * i1 + 1]) +
                          absx * b[3 * i1 + 2];
      }
      absxk_tmp_tmp = b_a[i];
      normA = b_a[i + 3];
      absx = b_a[i + 6];
      for (i1 = 0; i1 < 3; i1++) {
        a[i + 3 * i1] =
            (absxk_tmp_tmp * b_b[3 * i1] + normA * b_b[3 * i1 + 1]) +
            absx * b_b[3 * i1 + 2];
      }
      absxk_tmp_tmp = a[i];
      normA = a[i + 3];
      absx = a[i + 6];
      for (i1 = 0; i1 < 3; i1++) {
        b_a[i + 3 * i1] =
            (absxk_tmp_tmp * c_b[3 * i1] + normA * c_b[3 * i1 + 1]) +
            absx * c_b[3 * i1 + 2];
      }
      w_b[i] = params[i] * u[i] + x[i + 11];
    }
    a[0] = 0.0;
    a[3] = -s;
    a[6] = d;
    a[1] = s;
    a[4] = 0.0;
    a[7] = -y_tmp;
    a[2] = -d;
    a[5] = y_tmp;
    a[8] = 0.0;
    y_tmp = w_b[0];
    d = w_b[1];
    s = w_b[2];
    for (i = 0; i < 3; i++) {
      d_a[i] = (b_a[i] * y_tmp + b_a[i + 3] * d) + b_a[i + 6] * s;
    }
    for (i = 0; i < 3; i++) {
      w_b[i] = (a[i] * c_x_tmp + a[i + 3] * d_x_tmp) + a[i + 6] * e_x_tmp;
    }
    for (i = 0; i < 9; i++) {
      a[i] = -Sx_n_omega_ie[i];
    }
    dv[2] = x[3] + 6.3781E+6;
    for (i = 0; i < 3; i++) {
      y_tmp = 0.0;
      d = a[i];
      s = a[i + 3];
      absxk_tmp_tmp = a[i + 6];
      for (i1 = 0; i1 < 3; i1++) {
        y_tmp += ((d * Sx_n_omega_ie[3 * i1] + s * Sx_n_omega_ie[3 * i1 + 1]) +
                  absxk_tmp_tmp * Sx_n_omega_ie[3 * i1 + 2]) *
                 dv[i1];
      }
      e_a[i] = (d_a[i] - w_b[i]) + (y_tmp + dv2[i]);
    }
    y_tmp = x[4];
    d = x[5];
    s = x[6];
    absxk_tmp_tmp = x[7];
    for (i = 0; i < 4; i++) {
      q0[i] = ((c_a[i] * y_tmp + c_a[i + 4] * d) + c_a[i + 8] * s) +
              c_a[i + 12] * absxk_tmp_tmp;
    }
    memset(&dv1[0], 0, 11U * sizeof(real_T));
    b_x[0] = x[0] + params[6] * y;
    b_x[1] = x[1] + params[6] * (180.0 * v_scl_idx_0 /
                                 (3.1415926535897931 * (x[3] + 6.3568E+6)));
    b_x[2] =
        x[2] +
        params[6] * (-180.0 * v_scl_idx_1 /
                     (3.1415926535897931 * (x[3] + 6.3781E+6) * G_func_tmp));
    b_x[3] = x[3] + v_scl_idx_2 * params[6];
    b_x[4] = q0[0];
    b_x[5] = q0[1];
    b_x[6] = q0[2];
    b_x[7] = q0[3];
    b_x[8] = c_x_tmp + e_a[0] * params[6];
    b_x[9] = d_x_tmp + e_a[1] * params[6];
    b_x[10] = e_x_tmp + e_a[2] * params[6];
    for (i = 0; i < 6; i++) {
      dv1[i + 11] = x[i + 11];
      b_x[i + 11] = 0.0;
    }
    for (i = 0; i < 17; i++) {
      x[i] = dv1[i] + b_x[i];
    }
    odo_gen[ix + 1] = x[0];
    p_gen_tmp = 3 * (ix + 1);
    p_gen[p_gen_tmp] = x[1];
    p_gen[p_gen_tmp + 1] = x[2];
    p_gen[p_gen_tmp + 2] = x[3];
    s_tmp = (ix + 1) << 2;
    q[s_tmp] = x[4];
    q[s_tmp + 1] = x[5];
    q[s_tmp + 2] = x[6];
    q[s_tmp + 3] = x[7];
    v[p_gen_tmp] = x[8];
    v[p_gen_tmp + 1] = x[9];
    v[p_gen_tmp + 2] = x[10];
    /*   */
    q_dot[s_tmp] = (q[s_tmp] - q[absxk_tmp]) / dT;
    q_dot[s_tmp + 1] = (q[s_tmp + 1] - q[absxk_tmp + 1]) / dT;
    q_dot[s_tmp + 2] = (q[s_tmp + 2] - q[absxk_tmp + 2]) / dT;
    q_dot[s_tmp + 3] = (q[s_tmp + 3] - q[absxk_tmp + 3]) / dT;
    v_dot[p_gen_tmp] = (x[8] - v[3 * ix]) / dT;
    v_dot[p_gen_tmp + 1] = (x[9] - v[x_tmp]) / dT;
    v_dot[p_gen_tmp + 2] = (x[10] - v[b_x_tmp]) / dT;
    /* v_now = v(:,ix);  */
    st.site = &c_emlrtRSI;
    roty(&st, -x[1], a);
    st.site = &c_emlrtRSI;
    rotx(&st, -x[2], b);
    st.site = &d_emlrtRSI;
    rotx(&st,
         -(dT * (((real_T)ix + 2.0) - 1.0)) * 7.292115E-5 * 180.0 /
             3.1415926535897931,
         b_b);
    st.site = &d_emlrtRSI;
    quat2rotm(&st, *(real_T(*)[4]) & q[(ix + 1) << 2], c_b);
    /*  eul2rotm(flip(omega_ie(p)')*t) */
    for (i = 0; i < 3; i++) {
      y_tmp = a[i];
      d = a[i + 3];
      s = a[i + 6];
      for (i1 = 0; i1 < 3; i1++) {
        b_a[i + 3 * i1] =
            (y_tmp * b[3 * i1] + d * b[3 * i1 + 1]) + s * b[3 * i1 + 2];
      }
      y_tmp = b_a[i];
      d = b_a[i + 3];
      s = b_a[i + 6];
      for (i1 = 0; i1 < 3; i1++) {
        a[i + 3 * i1] =
            (y_tmp * b_b[3 * i1] + d * b_b[3 * i1 + 1]) + s * b_b[3 * i1 + 2];
      }
    }
    for (i = 0; i < 3; i++) {
      y_tmp = 0.0;
      d = c_b[3 * i];
      s = c_b[3 * i + 1];
      absxk_tmp_tmp = c_b[3 * i + 2];
      for (i1 = 0; i1 < 3; i1++) {
        y_tmp +=
            ((a[i1] * d + a[i1 + 3] * s) + a[i1 + 6] * absxk_tmp_tmp) * d_b[i1];
      }
      acc_ef[i + p_gen_tmp] = y_tmp;
    }
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b((emlrtCTX)sp);
    }
  }
  /*  odo_gen = odo_gain*dT*cumsum(sqrt(sum(v.*v,1)));  */
}

/* End of code generation
 * (get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld.c) */
