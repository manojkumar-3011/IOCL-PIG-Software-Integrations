/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld_api.c
 *
 * Code generation for function
 * '_coder_get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld_api'
 *
 */

/* Include files */
#include "_coder_get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld_api.h"
#include "get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld.h"
#include "get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld_data.h"
#include "rt_nonfinite.h"

/* Function Declarations */
static real_T (*b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u,
                                   const emlrtMsgIdentifier *parentId))[21];

static const mxArray *b_emlrt_marshallOut(const real_T u[318]);

static real_T (*c_emlrt_marshallIn(const emlrtStack *sp, const mxArray *indices,
                                   const char_T *identifier))[106];

static const mxArray *c_emlrt_marshallOut(const real_T u[106]);

static real_T (*d_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u,
                                   const emlrtMsgIdentifier *parentId))[106];

static real_T (*e_emlrt_marshallIn(const emlrtStack *sp, const mxArray *g_all,
                                   const char_T *identifier))[318];

static real_T (*emlrt_marshallIn(const emlrtStack *sp, const mxArray *new_agb_j,
                                 const char_T *identifier))[21];

static const mxArray *emlrt_marshallOut(const real_T u[424]);

static real_T (*f_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u,
                                   const emlrtMsgIdentifier *parentId))[318];

static real_T g_emlrt_marshallIn(const emlrtStack *sp,
                                 const mxArray *downsampling,
                                 const char_T *identifier);

static real_T h_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u,
                                 const emlrtMsgIdentifier *parentId);

static real_T (*i_emlrt_marshallIn(const emlrtStack *sp,
                                   const mxArray *start_gps,
                                   const char_T *identifier))[3];

static real_T (*j_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u,
                                   const emlrtMsgIdentifier *parentId))[3];

static real_T (*k_emlrt_marshallIn(const emlrtStack *sp,
                                   const mxArray *best_initial_orientation,
                                   const char_T *identifier))[4];

static real_T (*l_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u,
                                   const emlrtMsgIdentifier *parentId))[4];

static real_T (*m_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src,
                                   const emlrtMsgIdentifier *msgId))[21];

static real_T (*n_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src,
                                   const emlrtMsgIdentifier *msgId))[106];

static real_T (*o_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src,
                                   const emlrtMsgIdentifier *msgId))[318];

static real_T p_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src,
                                 const emlrtMsgIdentifier *msgId);

static real_T (*q_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src,
                                   const emlrtMsgIdentifier *msgId))[3];

static real_T (*r_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src,
                                   const emlrtMsgIdentifier *msgId))[4];

/* Function Definitions */
static real_T (*b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u,
                                   const emlrtMsgIdentifier *parentId))[21]
{
  real_T(*y)[21];
  y = m_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static const mxArray *b_emlrt_marshallOut(const real_T u[318])
{
  static const int32_T iv[2] = {0, 0};
  static const int32_T iv1[2] = {3, 106};
  const mxArray *m;
  const mxArray *y;
  y = NULL;
  m = emlrtCreateNumericArray(2, (const void *)&iv[0], mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m, (void *)&u[0]);
  emlrtSetDimensions((mxArray *)m, &iv1[0], 2);
  emlrtAssign(&y, m);
  return y;
}

static real_T (*c_emlrt_marshallIn(const emlrtStack *sp, const mxArray *indices,
                                   const char_T *identifier))[106]
{
  emlrtMsgIdentifier thisId;
  real_T(*y)[106];
  thisId.fIdentifier = (const char_T *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = d_emlrt_marshallIn(sp, emlrtAlias(indices), &thisId);
  emlrtDestroyArray(&indices);
  return y;
}

static const mxArray *c_emlrt_marshallOut(const real_T u[106])
{
  static const int32_T iv[2] = {0, 0};
  static const int32_T iv1[2] = {1, 106};
  const mxArray *m;
  const mxArray *y;
  y = NULL;
  m = emlrtCreateNumericArray(2, (const void *)&iv[0], mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m, (void *)&u[0]);
  emlrtSetDimensions((mxArray *)m, &iv1[0], 2);
  emlrtAssign(&y, m);
  return y;
}

static real_T (*d_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u,
                                   const emlrtMsgIdentifier *parentId))[106]
{
  real_T(*y)[106];
  y = n_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static real_T (*e_emlrt_marshallIn(const emlrtStack *sp, const mxArray *g_all,
                                   const char_T *identifier))[318]
{
  emlrtMsgIdentifier thisId;
  real_T(*y)[318];
  thisId.fIdentifier = (const char_T *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = f_emlrt_marshallIn(sp, emlrtAlias(g_all), &thisId);
  emlrtDestroyArray(&g_all);
  return y;
}

static real_T (*emlrt_marshallIn(const emlrtStack *sp, const mxArray *new_agb_j,
                                 const char_T *identifier))[21]
{
  emlrtMsgIdentifier thisId;
  real_T(*y)[21];
  thisId.fIdentifier = (const char_T *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = b_emlrt_marshallIn(sp, emlrtAlias(new_agb_j), &thisId);
  emlrtDestroyArray(&new_agb_j);
  return y;
}

static const mxArray *emlrt_marshallOut(const real_T u[424])
{
  static const int32_T iv[2] = {0, 0};
  static const int32_T iv1[2] = {4, 106};
  const mxArray *m;
  const mxArray *y;
  y = NULL;
  m = emlrtCreateNumericArray(2, (const void *)&iv[0], mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m, (void *)&u[0]);
  emlrtSetDimensions((mxArray *)m, &iv1[0], 2);
  emlrtAssign(&y, m);
  return y;
}

static real_T (*f_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u,
                                   const emlrtMsgIdentifier *parentId))[318]
{
  real_T(*y)[318];
  y = o_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static real_T g_emlrt_marshallIn(const emlrtStack *sp,
                                 const mxArray *downsampling,
                                 const char_T *identifier)
{
  emlrtMsgIdentifier thisId;
  real_T y;
  thisId.fIdentifier = (const char_T *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = h_emlrt_marshallIn(sp, emlrtAlias(downsampling), &thisId);
  emlrtDestroyArray(&downsampling);
  return y;
}

static real_T h_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u,
                                 const emlrtMsgIdentifier *parentId)
{
  real_T y;
  y = p_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static real_T (*i_emlrt_marshallIn(const emlrtStack *sp,
                                   const mxArray *start_gps,
                                   const char_T *identifier))[3]
{
  emlrtMsgIdentifier thisId;
  real_T(*y)[3];
  thisId.fIdentifier = (const char_T *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = j_emlrt_marshallIn(sp, emlrtAlias(start_gps), &thisId);
  emlrtDestroyArray(&start_gps);
  return y;
}

static real_T (*j_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u,
                                   const emlrtMsgIdentifier *parentId))[3]
{
  real_T(*y)[3];
  y = q_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static real_T (*k_emlrt_marshallIn(const emlrtStack *sp,
                                   const mxArray *best_initial_orientation,
                                   const char_T *identifier))[4]
{
  emlrtMsgIdentifier thisId;
  real_T(*y)[4];
  thisId.fIdentifier = (const char_T *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = l_emlrt_marshallIn(sp, emlrtAlias(best_initial_orientation), &thisId);
  emlrtDestroyArray(&best_initial_orientation);
  return y;
}

static real_T (*l_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u,
                                   const emlrtMsgIdentifier *parentId))[4]
{
  real_T(*y)[4];
  y = r_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static real_T (*m_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src,
                                   const emlrtMsgIdentifier *msgId))[21]
{
  static const int32_T dims = 21;
  real_T(*ret)[21];
  emlrtCheckBuiltInR2012b((emlrtCTX)sp, msgId, src, (const char_T *)"double",
                          false, 1U, (void *)&dims);
  ret = (real_T(*)[21])emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

static real_T (*n_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src,
                                   const emlrtMsgIdentifier *msgId))[106]
{
  static const int32_T dims[2] = {1, 106};
  real_T(*ret)[106];
  emlrtCheckBuiltInR2012b((emlrtCTX)sp, msgId, src, (const char_T *)"double",
                          false, 2U, (void *)&dims[0]);
  ret = (real_T(*)[106])emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

static real_T (*o_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src,
                                   const emlrtMsgIdentifier *msgId))[318]
{
  static const int32_T dims[2] = {3, 106};
  real_T(*ret)[318];
  emlrtCheckBuiltInR2012b((emlrtCTX)sp, msgId, src, (const char_T *)"double",
                          false, 2U, (void *)&dims[0]);
  ret = (real_T(*)[318])emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

static real_T p_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src,
                                 const emlrtMsgIdentifier *msgId)
{
  static const int32_T dims = 0;
  real_T ret;
  emlrtCheckBuiltInR2012b((emlrtCTX)sp, msgId, src, (const char_T *)"double",
                          false, 0U, (void *)&dims);
  ret = *(real_T *)emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

static real_T (*q_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src,
                                   const emlrtMsgIdentifier *msgId))[3]
{
  static const int32_T dims[2] = {1, 3};
  real_T(*ret)[3];
  emlrtCheckBuiltInR2012b((emlrtCTX)sp, msgId, src, (const char_T *)"double",
                          false, 2U, (void *)&dims[0]);
  ret = (real_T(*)[3])emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

static real_T (*r_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src,
                                   const emlrtMsgIdentifier *msgId))[4]
{
  static const int32_T dims = 4;
  real_T(*ret)[4];
  emlrtCheckBuiltInR2012b((emlrtCTX)sp, msgId, src, (const char_T *)"double",
                          false, 1U, (void *)&dims);
  ret = (real_T(*)[4])emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

void c_get_full_dynamical_trajectory(const mxArray *const prhs[7], int32_T nlhs,
                                     const mxArray *plhs[7])
{
  emlrtStack st = {
      NULL, /* site */
      NULL, /* tls */
      NULL  /* prev */
  };
  real_T(*q)[424];
  real_T(*q_dot)[424];
  real_T(*acc_ef)[318];
  real_T(*g_all)[318];
  real_T(*p_gen)[318];
  real_T(*v)[318];
  real_T(*v_dot)[318];
  real_T(*w_all)[318];
  real_T(*indices)[106];
  real_T(*odo_gen)[106];
  real_T(*new_agb_j)[21];
  real_T(*best_initial_orientation)[4];
  real_T(*start_gps)[3];
  real_T downsampling;
  st.tls = emlrtRootTLSGlobal;
  q_dot = (real_T(*)[424])mxMalloc(sizeof(real_T[424]));
  q = (real_T(*)[424])mxMalloc(sizeof(real_T[424]));
  v_dot = (real_T(*)[318])mxMalloc(sizeof(real_T[318]));
  v = (real_T(*)[318])mxMalloc(sizeof(real_T[318]));
  p_gen = (real_T(*)[318])mxMalloc(sizeof(real_T[318]));
  odo_gen = (real_T(*)[106])mxMalloc(sizeof(real_T[106]));
  acc_ef = (real_T(*)[318])mxMalloc(sizeof(real_T[318]));
  /* Marshall function inputs */
  new_agb_j = emlrt_marshallIn(&st, emlrtAlias(prhs[0]), "new_agb_j");
  indices = c_emlrt_marshallIn(&st, emlrtAlias(prhs[1]), "indices");
  g_all = e_emlrt_marshallIn(&st, emlrtAlias(prhs[2]), "g_all");
  w_all = e_emlrt_marshallIn(&st, emlrtAlias(prhs[3]), "w_all");
  downsampling = g_emlrt_marshallIn(&st, emlrtAliasP(prhs[4]), "downsampling");
  start_gps = i_emlrt_marshallIn(&st, emlrtAlias(prhs[5]), "start_gps");
  best_initial_orientation =
      k_emlrt_marshallIn(&st, emlrtAlias(prhs[6]), "best_initial_orientation");
  /* Invoke the target function */
  get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld(
      &st, *new_agb_j, *indices, *g_all, *w_all, downsampling, *start_gps,
      *best_initial_orientation, *q_dot, *q, *v_dot, *v, *p_gen, *odo_gen,
      *acc_ef);
  /* Marshall function outputs */
  plhs[0] = emlrt_marshallOut(*q_dot);
  if (nlhs > 1) {
    plhs[1] = emlrt_marshallOut(*q);
  }
  if (nlhs > 2) {
    plhs[2] = b_emlrt_marshallOut(*v_dot);
  }
  if (nlhs > 3) {
    plhs[3] = b_emlrt_marshallOut(*v);
  }
  if (nlhs > 4) {
    plhs[4] = b_emlrt_marshallOut(*p_gen);
  }
  if (nlhs > 5) {
    plhs[5] = c_emlrt_marshallOut(*odo_gen);
  }
  if (nlhs > 6) {
    plhs[6] = b_emlrt_marshallOut(*acc_ef);
  }
}

/* End of code generation
 * (_coder_get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld_api.c) */
