/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld_info.c
 *
 * Code generation for function
 * 'get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld'
 *
 */

/* Include files */
#include "_coder_get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

/* Function Definitions */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[5] = {
      "789cc553cd4ec240105e0c120fa25cbcf304c684a80937c34fe2a106844413d7aca59d42"
      "65bb5b77b7509ec2b36fe1a378f6093cfb025a2c85d264030901e732"
      "fbf5cbcc37f36d17e5ae8d1c42e808c5f155887371864bb3bc879623cbe73439897d945f"
      "aa4bf8d759b6385310aa1830d38379a5cd3d97994c75273e200192d3",
      "11d87f8ce352e8ba1e74d2e0668abc668a9a8329353dd706600d3b8187c4402e26a46930"
      "f7231934bb6f7e4d3fde347e9432fc43e3b159c557966983e75ab82e"
      "b8dfe321be050b98c2775c0cdb35dc087d10d1224cc9b2c3455909934907046e765a6404"
      "e28c481fc0c65d908a188d7b5c370ce24188fba08813504aec49e4ad",
      "6b999444b5cf60292e2624606e542ca38f011b8e19b1bb51334aa445ed532fe387afd977"
      "5d3f0e57f891f0bedb4f869569fda70df50b5afd98b179d0a3b0d0fb"
      "d8508f6af596f9edde7fdacdf84a57f979bce67ebaf75e4407717ff999dba5defbcf7775"
      "977a49fc975ea8e9b7eeff79a2d12b6578c3af5f98edb1c93a2fc1e5",
      "6454719a95f6796a8ed60a9d5573200dde76ff5fefc9a837", ""};
  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 1792U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[6] = {
      "Name",           "NumberOfInputs", "NumberOfOutputs",
      "ConstantInputs", "FullPath",       "TimeStamp"};
  const char_T *propFieldName[5] = {"Version", "ResolvedFunctions",
                                    "EntryPoints", "CoverageInfo",
                                    "IsPolymorphic"};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 1, 6, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 7);
  emlrtSetField(
      xEntryPoints, 0, (const char_T *)"Name",
      emlrtMxCreateString(
          (const char_T
               *)"get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld"));
  emlrtSetField(xEntryPoints, 0, (const char_T *)"NumberOfInputs",
                emlrtMxCreateDoubleScalar(7.0));
  emlrtSetField(xEntryPoints, 0, (const char_T *)"NumberOfOutputs",
                emlrtMxCreateDoubleScalar(7.0));
  emlrtSetField(xEntryPoints, 0, (const char_T *)"ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, (const char_T *)"FullPath",
      emlrtMxCreateString(
          (const char_T
               *)"F:\\Academic\\Dropbox\\Recent\\WorkQC\\Experiments for "
                 "transfer\\FSP_ver0_speed\\Test_MEX\\DMM_mex\\get_full_"
                 "dynamical_trajectory_univers"
                 "al_unkwn_dT_vel_scld.m"));
  emlrtSetField(xEntryPoints, 0, (const char_T *)"TimeStamp",
                emlrtMxCreateDoubleScalar(739322.37193287036));
  xResult =
      emlrtCreateStructMatrix(1, 1, 5, (const char_T **)&propFieldName[0]);
  emlrtSetField(
      xResult, 0, (const char_T *)"Version",
      emlrtMxCreateString((const char_T *)"9.11.0.1873467 (R2021b) Update 3"));
  emlrtSetField(xResult, 0, (const char_T *)"ResolvedFunctions",
                (mxArray *)emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, (const char_T *)"EntryPoints", xEntryPoints);
  return xResult;
}

/* End of code generation
 * (_coder_get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld_info.c) */
