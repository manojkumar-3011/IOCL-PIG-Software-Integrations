/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * quat2rotm.c
 *
 * Code generation for function 'quat2rotm'
 *
 */

/* Include files */
#include "quat2rotm.h"
#include "get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld_data.h"
#include "rt_nonfinite.h"
#include "sumMatrixIncludeNaN.h"
#include "mwmathutil.h"
#include <string.h>

/* Variable Definitions */
static emlrtRSInfo i_emlrtRSI =
    {
        32,          /* lineNo */
        "quat2rotm", /* fcnName */
        "C:\\Program "
        "Files\\MATLAB\\R2021b\\toolbox\\shared\\robotics\\robotutils\\quat2rot"
        "m.m" /* pathName */
};

static emlrtRSInfo j_emlrtRSI =
    {
        43,          /* lineNo */
        "quat2rotm", /* fcnName */
        "C:\\Program "
        "Files\\MATLAB\\R2021b\\toolbox\\shared\\robotics\\robotutils\\quat2rot"
        "m.m" /* pathName */
};

static emlrtRSInfo k_emlrtRSI =
    {
        44,          /* lineNo */
        "quat2rotm", /* fcnName */
        "C:\\Program "
        "Files\\MATLAB\\R2021b\\toolbox\\shared\\robotics\\robotutils\\quat2rot"
        "m.m" /* pathName */
};

static emlrtRSInfo l_emlrtRSI =
    {
        45,          /* lineNo */
        "quat2rotm", /* fcnName */
        "C:\\Program "
        "Files\\MATLAB\\R2021b\\toolbox\\shared\\robotics\\robotutils\\quat2rot"
        "m.m" /* pathName */
};

static emlrtRSInfo m_emlrtRSI = {
    15,              /* lineNo */
    "normalizeRows", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\shared\\robotics\\robotutils\\+robotics\\+"
    "internal\\normalizeRows.m" /* pathName */
};

/* Function Definitions */
void quat2rotm(const emlrtStack *sp, const real_T q[4], real_T R[9])
{
  emlrtStack b_st;
  emlrtStack st;
  real_T tempR[9];
  real_T normRowMatrix[4];
  real_T b_tempR_tmp;
  real_T c_tempR_tmp;
  real_T d_tempR_tmp;
  real_T e_tempR_tmp;
  real_T tempR_tmp;
  real_T x;
  int32_T R_tmp;
  int32_T k;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &i_emlrtRSI;
  b_st.prev = &st;
  b_st.tls = st.tls;
  normRowMatrix[0] = q[0] * q[0];
  normRowMatrix[1] = q[1] * q[1];
  normRowMatrix[2] = q[2] * q[2];
  normRowMatrix[3] = q[3] * q[3];
  x = sumColumnB(normRowMatrix);
  b_st.site = &m_emlrtRSI;
  if (x < 0.0) {
    emlrtErrorWithMessageIdR2018a(
        &b_st, &d_emlrtRTEI, "Coder:toolbox:ElFunDomainError",
        "Coder:toolbox:ElFunDomainError", 3, 4, 4, "sqrt");
  }
  x = muDoubleScalarSqrt(x);
  x = 1.0 / x;
  normRowMatrix[0] = q[0] * x;
  normRowMatrix[1] = q[1] * x;
  normRowMatrix[2] = q[2] * x;
  normRowMatrix[3] = q[3] * x;
  st.site = &j_emlrtRSI;
  st.site = &j_emlrtRSI;
  st.site = &k_emlrtRSI;
  st.site = &k_emlrtRSI;
  st.site = &l_emlrtRSI;
  st.site = &l_emlrtRSI;
  x = normRowMatrix[3] * normRowMatrix[3];
  tempR_tmp = normRowMatrix[2] * normRowMatrix[2];
  tempR[0] = 1.0 - 2.0 * (tempR_tmp + x);
  b_tempR_tmp = normRowMatrix[1] * normRowMatrix[2];
  c_tempR_tmp = normRowMatrix[0] * normRowMatrix[3];
  tempR[1] = 2.0 * (b_tempR_tmp - c_tempR_tmp);
  d_tempR_tmp = normRowMatrix[1] * normRowMatrix[3];
  e_tempR_tmp = normRowMatrix[0] * normRowMatrix[2];
  tempR[2] = 2.0 * (d_tempR_tmp + e_tempR_tmp);
  tempR[3] = 2.0 * (b_tempR_tmp + c_tempR_tmp);
  b_tempR_tmp = normRowMatrix[1] * normRowMatrix[1];
  tempR[4] = 1.0 - 2.0 * (b_tempR_tmp + x);
  x = normRowMatrix[2] * normRowMatrix[3];
  c_tempR_tmp = normRowMatrix[0] * normRowMatrix[1];
  tempR[5] = 2.0 * (x - c_tempR_tmp);
  tempR[6] = 2.0 * (d_tempR_tmp - e_tempR_tmp);
  tempR[7] = 2.0 * (x + c_tempR_tmp);
  tempR[8] = 1.0 - 2.0 * (b_tempR_tmp + tempR_tmp);
  memcpy(&R[0], &tempR[0], 9U * sizeof(real_T));
  for (k = 0; k < 3; k++) {
    R_tmp = 3 * k;
    R[k] = tempR[R_tmp];
    R[k + 3] = tempR[R_tmp + 1];
    R[k + 6] = tempR[R_tmp + 2];
  }
}

/* End of code generation (quat2rotm.c) */
