/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * expm.c
 *
 * Code generation for function 'expm'
 *
 */

/* Include files */
#include "expm.h"
#include "eml_int_forloop_overflow_check.h"
#include "get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld_data.h"
#include "rt_nonfinite.h"
#include "warning.h"
#include "mwmathutil.h"
#include <string.h>

/* Variable Definitions */
static emlrtRSInfo rd_emlrtRSI = {
    175,                       /* lineNo */
    "PadeApproximantOfDegree", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" /* pathName
                                                                        */
};

static emlrtRSInfo
    sd_emlrtRSI =
        {
            67,        /* lineNo */
            "lusolve", /* fcnName */
            "C:\\Program "
            "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+"
            "internal\\lusolve.m" /* pathName */
};

static emlrtRSInfo
    td_emlrtRSI =
        {
            112,          /* lineNo */
            "lusolveNxN", /* fcnName */
            "C:\\Program "
            "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+"
            "internal\\lusolve.m" /* pathName */
};

static emlrtRSInfo
    ud_emlrtRSI =
        {
            109,          /* lineNo */
            "lusolveNxN", /* fcnName */
            "C:\\Program "
            "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+"
            "internal\\lusolve.m" /* pathName */
};

static emlrtRSInfo
    vd_emlrtRSI =
        {
            124,          /* lineNo */
            "InvAtimesX", /* fcnName */
            "C:\\Program "
            "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+"
            "internal\\lusolve.m" /* pathName */
};

static emlrtRSInfo wd_emlrtRSI = {
    26,        /* lineNo */
    "xgetrfs", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgetrfs.m" /* pathName */
};

static emlrtRSInfo xd_emlrtRSI = {
    27,        /* lineNo */
    "xgetrfs", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgetrfs.m" /* pathName */
};

static emlrtRSInfo yd_emlrtRSI = {
    30,       /* lineNo */
    "xgetrf", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgetrf.m" /* pathName */
};

static emlrtRSInfo ae_emlrtRSI = {
    50,        /* lineNo */
    "xzgetrf", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "reflapack\\xzgetrf.m" /* pathName */
};

static emlrtRSInfo be_emlrtRSI = {
    58,        /* lineNo */
    "xzgetrf", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "reflapack\\xzgetrf.m" /* pathName */
};

static emlrtRSInfo ce_emlrtRSI = {
    45,      /* lineNo */
    "xgeru", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+blas\\xgeru."
    "m" /* pathName */
};

static emlrtRSInfo de_emlrtRSI = {
    18,       /* lineNo */
    "xgetrs", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgetrs.m" /* pathName */
};

static emlrtRSInfo ee_emlrtRSI = {
    36,        /* lineNo */
    "xzgetrs", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "reflapack\\xzgetrs.m" /* pathName */
};

static emlrtRSInfo fe_emlrtRSI = {
    59,      /* lineNo */
    "xtrsm", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+blas\\xtrsm."
    "m" /* pathName */
};

static emlrtRSInfo ge_emlrtRSI = {
    51,      /* lineNo */
    "xtrsm", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "refblas\\xtrsm.m" /* pathName */
};

static emlrtRSInfo
    he_emlrtRSI =
        {
            90,              /* lineNo */
            "warn_singular", /* fcnName */
            "C:\\Program "
            "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+"
            "internal\\lusolve.m" /* pathName */
};

/* Function Definitions */
void PadeApproximantOfDegree(const emlrtStack *sp, const real_T A[16],
                             uint8_T m, real_T F[16])
{
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  emlrtStack g_st;
  emlrtStack h_st;
  emlrtStack i_st;
  emlrtStack j_st;
  emlrtStack k_st;
  emlrtStack l_st;
  emlrtStack st;
  real_T A2[16];
  real_T A3[16];
  real_T A4[16];
  real_T V[16];
  real_T b_A4[16];
  real_T b_d;
  real_T d;
  real_T d1;
  real_T s;
  int32_T b_tmp;
  int32_T i;
  int32_T info;
  int32_T j;
  int32_T jA;
  int32_T jBcol;
  int32_T jp1j;
  int32_T k;
  int32_T n;
  int8_T ipiv[4];
  int8_T b_i;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  g_st.prev = &f_st;
  g_st.tls = f_st.tls;
  h_st.prev = &g_st;
  h_st.tls = g_st.tls;
  i_st.prev = &h_st;
  i_st.tls = h_st.tls;
  j_st.prev = &i_st;
  j_st.tls = i_st.tls;
  k_st.prev = &j_st;
  k_st.tls = j_st.tls;
  l_st.prev = &k_st;
  l_st.tls = k_st.tls;
  for (n = 0; n < 4; n++) {
    for (b_tmp = 0; b_tmp < 4; b_tmp++) {
      jBcol = b_tmp << 2;
      A2[n + jBcol] = ((A[n] * A[jBcol] + A[n + 4] * A[jBcol + 1]) +
                       A[n + 8] * A[jBcol + 2]) +
                      A[n + 12] * A[jBcol + 3];
    }
  }
  if (m == 3) {
    memcpy(&F[0], &A2[0], 16U * sizeof(real_T));
    F[0] += 60.0;
    F[5] += 60.0;
    F[10] += 60.0;
    F[15] += 60.0;
    for (n = 0; n < 4; n++) {
      d = A[n];
      s = A[n + 4];
      b_d = A[n + 8];
      d1 = A[n + 12];
      for (b_tmp = 0; b_tmp < 4; b_tmp++) {
        jBcol = b_tmp << 2;
        b_A4[n + jBcol] =
            ((d * F[jBcol] + s * F[jBcol + 1]) + b_d * F[jBcol + 2]) +
            d1 * F[jBcol + 3];
      }
    }
    for (n = 0; n < 16; n++) {
      F[n] = b_A4[n];
      V[n] = 12.0 * A2[n];
    }
    d = 120.0;
  } else {
    for (n = 0; n < 4; n++) {
      for (b_tmp = 0; b_tmp < 4; b_tmp++) {
        jBcol = b_tmp << 2;
        A3[n + jBcol] = ((A2[n] * A2[jBcol] + A2[n + 4] * A2[jBcol + 1]) +
                         A2[n + 8] * A2[jBcol + 2]) +
                        A2[n + 12] * A2[jBcol + 3];
      }
    }
    if (m == 5) {
      for (n = 0; n < 16; n++) {
        F[n] = A3[n] + 420.0 * A2[n];
      }
      F[0] += 15120.0;
      F[5] += 15120.0;
      F[10] += 15120.0;
      F[15] += 15120.0;
      for (n = 0; n < 4; n++) {
        d = A[n];
        s = A[n + 4];
        b_d = A[n + 8];
        d1 = A[n + 12];
        for (b_tmp = 0; b_tmp < 4; b_tmp++) {
          jBcol = b_tmp << 2;
          b_A4[n + jBcol] =
              ((d * F[jBcol] + s * F[jBcol + 1]) + b_d * F[jBcol + 2]) +
              d1 * F[jBcol + 3];
        }
      }
      for (n = 0; n < 16; n++) {
        F[n] = b_A4[n];
        V[n] = 30.0 * A3[n] + 3360.0 * A2[n];
      }
      d = 30240.0;
    } else {
      for (n = 0; n < 4; n++) {
        d = A3[n];
        s = A3[n + 4];
        b_d = A3[n + 8];
        d1 = A3[n + 12];
        for (b_tmp = 0; b_tmp < 4; b_tmp++) {
          jBcol = b_tmp << 2;
          A4[n + jBcol] =
              ((d * A2[jBcol] + s * A2[jBcol + 1]) + b_d * A2[jBcol + 2]) +
              d1 * A2[jBcol + 3];
        }
      }
      if (m == 7) {
        for (n = 0; n < 16; n++) {
          F[n] = (A4[n] + 1512.0 * A3[n]) + 277200.0 * A2[n];
        }
        F[0] += 8.64864E+6;
        F[5] += 8.64864E+6;
        F[10] += 8.64864E+6;
        F[15] += 8.64864E+6;
        for (n = 0; n < 4; n++) {
          d = A[n];
          s = A[n + 4];
          b_d = A[n + 8];
          d1 = A[n + 12];
          for (b_tmp = 0; b_tmp < 4; b_tmp++) {
            jBcol = b_tmp << 2;
            b_A4[n + jBcol] =
                ((d * F[jBcol] + s * F[jBcol + 1]) + b_d * F[jBcol + 2]) +
                d1 * F[jBcol + 3];
          }
        }
        for (n = 0; n < 16; n++) {
          F[n] = b_A4[n];
          V[n] = (56.0 * A4[n] + 25200.0 * A3[n]) + 1.99584E+6 * A2[n];
        }
        d = 1.729728E+7;
      } else if (m == 9) {
        for (n = 0; n < 4; n++) {
          d = A4[n];
          s = A4[n + 4];
          b_d = A4[n + 8];
          d1 = A4[n + 12];
          for (b_tmp = 0; b_tmp < 4; b_tmp++) {
            jBcol = b_tmp << 2;
            V[n + jBcol] =
                ((d * A2[jBcol] + s * A2[jBcol + 1]) + b_d * A2[jBcol + 2]) +
                d1 * A2[jBcol + 3];
          }
        }
        for (n = 0; n < 16; n++) {
          F[n] = ((V[n] + 3960.0 * A4[n]) + 2.16216E+6 * A3[n]) +
                 3.027024E+8 * A2[n];
        }
        F[0] += 8.8216128E+9;
        F[5] += 8.8216128E+9;
        F[10] += 8.8216128E+9;
        F[15] += 8.8216128E+9;
        for (n = 0; n < 4; n++) {
          d = A[n];
          s = A[n + 4];
          b_d = A[n + 8];
          d1 = A[n + 12];
          for (b_tmp = 0; b_tmp < 4; b_tmp++) {
            jBcol = b_tmp << 2;
            b_A4[n + jBcol] =
                ((d * F[jBcol] + s * F[jBcol + 1]) + b_d * F[jBcol + 2]) +
                d1 * F[jBcol + 3];
          }
        }
        for (n = 0; n < 16; n++) {
          F[n] = b_A4[n];
          V[n] = ((90.0 * V[n] + 110880.0 * A4[n]) + 3.027024E+7 * A3[n]) +
                 2.0756736E+9 * A2[n];
        }
        d = 1.76432256E+10;
      } else {
        for (n = 0; n < 16; n++) {
          d = A4[n];
          s = A3[n];
          b_d = A2[n];
          F[n] = (3.352212864E+10 * d + 1.05594705216E+13 * s) +
                 1.1873537964288E+15 * b_d;
          b_A4[n] = (d + 16380.0 * s) + 4.08408E+7 * b_d;
        }
        F[0] += 3.238237626624E+16;
        F[5] += 3.238237626624E+16;
        F[10] += 3.238237626624E+16;
        F[15] += 3.238237626624E+16;
        for (n = 0; n < 4; n++) {
          d = A4[n];
          s = A4[n + 4];
          b_d = A4[n + 8];
          d1 = A4[n + 12];
          for (b_tmp = 0; b_tmp < 4; b_tmp++) {
            jBcol = b_tmp << 2;
            jA = n + jBcol;
            V[jA] = (((d * b_A4[jBcol] + s * b_A4[jBcol + 1]) +
                      b_d * b_A4[jBcol + 2]) +
                     d1 * b_A4[jBcol + 3]) +
                    F[jA];
          }
        }
        for (n = 0; n < 4; n++) {
          d = A[n];
          s = A[n + 4];
          b_d = A[n + 8];
          d1 = A[n + 12];
          for (b_tmp = 0; b_tmp < 4; b_tmp++) {
            jBcol = b_tmp << 2;
            F[n + jBcol] =
                ((d * V[jBcol] + s * V[jBcol + 1]) + b_d * V[jBcol + 2]) +
                d1 * V[jBcol + 3];
          }
        }
        for (n = 0; n < 16; n++) {
          b_A4[n] = (182.0 * A4[n] + 960960.0 * A3[n]) + 1.32324192E+9 * A2[n];
        }
        for (n = 0; n < 4; n++) {
          for (b_tmp = 0; b_tmp < 4; b_tmp++) {
            jBcol = b_tmp << 2;
            jA = n + jBcol;
            V[jA] = (((((A4[n] * b_A4[jBcol] + A4[n + 4] * b_A4[jBcol + 1]) +
                        A4[n + 8] * b_A4[jBcol + 2]) +
                       A4[n + 12] * b_A4[jBcol + 3]) +
                      6.704425728E+11 * A4[jA]) +
                     1.29060195264E+14 * A3[jA]) +
                    7.7717703038976E+15 * A2[jA];
          }
        }
        d = 6.476475253248E+16;
      }
    }
  }
  V[0] += d;
  V[5] += d;
  V[10] += d;
  V[15] += d;
  for (k = 0; k < 16; k++) {
    d = F[k];
    V[k] -= d;
    d *= 2.0;
    F[k] = d;
  }
  st.site = &rd_emlrtRSI;
  b_st.site = &sd_emlrtRSI;
  c_st.site = &ud_emlrtRSI;
  d_st.site = &vd_emlrtRSI;
  e_st.site = &wd_emlrtRSI;
  f_st.site = &yd_emlrtRSI;
  ipiv[0] = 1;
  ipiv[1] = 2;
  ipiv[2] = 3;
  ipiv[3] = 4;
  info = 0;
  for (j = 0; j < 3; j++) {
    b_tmp = j * 5;
    jp1j = b_tmp + 2;
    n = 4 - j;
    jA = 0;
    d = muDoubleScalarAbs(V[b_tmp]);
    for (k = 2; k <= n; k++) {
      s = muDoubleScalarAbs(V[(b_tmp + k) - 1]);
      if (s > d) {
        jA = k - 1;
        d = s;
      }
    }
    if (V[b_tmp + jA] != 0.0) {
      if (jA != 0) {
        jBcol = j + jA;
        ipiv[j] = (int8_T)(jBcol + 1);
        d = V[j];
        V[j] = V[jBcol];
        V[jBcol] = d;
        d = V[j + 4];
        V[j + 4] = V[jBcol + 4];
        V[jBcol + 4] = d;
        d = V[j + 8];
        V[j + 8] = V[jBcol + 8];
        V[jBcol + 8] = d;
        d = V[j + 12];
        V[j + 12] = V[jBcol + 12];
        V[jBcol + 12] = d;
      }
      jBcol = (b_tmp - j) + 4;
      g_st.site = &ae_emlrtRSI;
      for (i = jp1j; i <= jBcol; i++) {
        V[i - 1] /= V[b_tmp];
      }
    } else {
      info = j + 1;
    }
    n = 2 - j;
    g_st.site = &be_emlrtRSI;
    h_st.site = &ce_emlrtRSI;
    i_st.site = &yb_emlrtRSI;
    j_st.site = &ac_emlrtRSI;
    jA = b_tmp + 6;
    k_st.site = &bc_emlrtRSI;
    for (jp1j = 0; jp1j <= n; jp1j++) {
      d = V[(b_tmp + (jp1j << 2)) + 4];
      if (d != 0.0) {
        jBcol = (jA - j) + 2;
        k_st.site = &cc_emlrtRSI;
        if ((jA <= jBcol) && (jBcol > 2147483646)) {
          l_st.site = &w_emlrtRSI;
          check_forloop_overflow_error(&l_st);
        }
        for (i = jA; i <= jBcol; i++) {
          V[i - 1] += V[((b_tmp + i) - jA) + 1] * -d;
        }
      }
      jA += 4;
    }
  }
  if ((info == 0) && (!(V[15] != 0.0))) {
    info = 4;
  }
  e_st.site = &xd_emlrtRSI;
  f_st.site = &de_emlrtRSI;
  for (i = 0; i < 3; i++) {
    b_i = ipiv[i];
    if (b_i != i + 1) {
      d = F[i];
      F[i] = F[b_i - 1];
      F[b_i - 1] = d;
      d = F[i + 4];
      F[i + 4] = F[b_i + 3];
      F[b_i + 3] = d;
      d = F[i + 8];
      F[i + 8] = F[b_i + 7];
      F[b_i + 7] = d;
      d = F[i + 12];
      F[i + 12] = F[b_i + 11];
      F[b_i + 11] = d;
    }
  }
  for (j = 0; j < 4; j++) {
    jBcol = j << 2;
    for (k = 0; k < 4; k++) {
      jA = k << 2;
      n = k + jBcol;
      if (F[n] != 0.0) {
        b_tmp = k + 2;
        for (i = b_tmp; i < 5; i++) {
          jp1j = (i + jBcol) - 1;
          F[jp1j] -= F[n] * V[(i + jA) - 1];
        }
      }
    }
  }
  g_st.site = &ee_emlrtRSI;
  h_st.site = &fe_emlrtRSI;
  for (j = 0; j < 4; j++) {
    jBcol = j << 2;
    for (k = 3; k >= 0; k--) {
      jA = k << 2;
      n = k + jBcol;
      d = F[n];
      if (d != 0.0) {
        F[n] = d / V[k + jA];
        i_st.site = &ge_emlrtRSI;
        for (i = 0; i < k; i++) {
          jp1j = i + jBcol;
          F[jp1j] -= F[n] * V[i + jA];
        }
      }
    }
  }
  if (info > 0) {
    c_st.site = &td_emlrtRSI;
    d_st.site = &he_emlrtRSI;
    c_warning(&d_st);
  }
  F[0]++;
  F[5]++;
  F[10]++;
  F[15]++;
}

/* End of code generation (expm.c) */
