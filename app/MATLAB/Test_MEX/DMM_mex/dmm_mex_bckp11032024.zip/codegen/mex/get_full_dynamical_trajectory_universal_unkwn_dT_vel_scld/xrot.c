/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * xrot.c
 *
 * Code generation for function 'xrot'
 *
 */

/* Include files */
#include "xrot.h"
#include "eml_int_forloop_overflow_check.h"
#include "get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
static emlrtRSInfo cd_emlrtRSI =
    {
        32,     /* lineNo */
        "xrot", /* fcnName */
        "C:\\Program "
        "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
        "blas\\xrot.m" /* pathName */
};

static emlrtRSInfo dd_emlrtRSI = {
    24,     /* lineNo */
    "xrot", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "refblas\\xrot.m" /* pathName */
};

/* Function Definitions */
void b_xrot(const emlrtStack *sp, int32_T n, real_T x[16], int32_T ix0,
            int32_T iy0, real_T c, real_T s)
{
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack st;
  real_T b_temp_tmp;
  real_T d_temp_tmp;
  int32_T c_temp_tmp;
  int32_T k;
  int32_T temp_tmp;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &cd_emlrtRSI;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  if (n >= 1) {
    b_st.site = &dd_emlrtRSI;
    if (n > 2147483646) {
      c_st.site = &w_emlrtRSI;
      check_forloop_overflow_error(&c_st);
    }
    for (k = 0; k < n; k++) {
      temp_tmp = (iy0 + k) - 1;
      b_temp_tmp = x[temp_tmp];
      c_temp_tmp = (ix0 + k) - 1;
      d_temp_tmp = x[c_temp_tmp];
      x[temp_tmp] = c * b_temp_tmp - s * d_temp_tmp;
      x[c_temp_tmp] = c * d_temp_tmp + s * b_temp_tmp;
    }
  }
}

void xrot(const emlrtStack *sp, int32_T n, real_T x[16], int32_T ix0,
          int32_T iy0, real_T c, real_T s)
{
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack st;
  real_T c_temp_tmp;
  real_T d_temp_tmp;
  int32_T b_temp_tmp;
  int32_T k;
  int32_T temp_tmp;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &cd_emlrtRSI;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  b_st.site = &dd_emlrtRSI;
  if ((1 <= n) && (n > 2147483646)) {
    c_st.site = &w_emlrtRSI;
    check_forloop_overflow_error(&c_st);
  }
  for (k = 0; k < n; k++) {
    temp_tmp = k << 2;
    b_temp_tmp = (iy0 + temp_tmp) - 1;
    c_temp_tmp = x[b_temp_tmp];
    temp_tmp = (ix0 + temp_tmp) - 1;
    d_temp_tmp = x[temp_tmp];
    x[b_temp_tmp] = c * c_temp_tmp - s * d_temp_tmp;
    x[temp_tmp] = c * d_temp_tmp + s * c_temp_tmp;
  }
}

/* End of code generation (xrot.c) */
