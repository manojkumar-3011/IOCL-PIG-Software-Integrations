/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld.h
 *
 * Code generation for function
 * 'get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld'
 *
 */

#pragma once

/* Include files */
#include "rtwtypes.h"
#include "emlrt.h"
#include "mex.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Function Declarations */
void get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld(
    const emlrtStack *sp, const real_T new_agb_j[21], const real_T indices[106],
    const real_T g_all[318], const real_T w_all[318], real_T downsampling,
    const real_T start_gps[3], const real_T best_initial_orientation[4],
    real_T q_dot[424], real_T q[424], real_T v_dot[318], real_T v[318],
    real_T p_gen[318], real_T odo_gen[106], real_T acc_ef[318]);

/* End of code generation
 * (get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld.h) */
