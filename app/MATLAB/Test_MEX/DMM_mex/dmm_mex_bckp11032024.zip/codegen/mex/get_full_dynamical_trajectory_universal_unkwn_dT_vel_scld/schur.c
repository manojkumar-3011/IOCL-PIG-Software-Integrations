/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * schur.c
 *
 * Code generation for function 'schur'
 *
 */

/* Include files */
#include "schur.h"
#include "anyNonFinite.h"
#include "eml_int_forloop_overflow_check.h"
#include "get_full_dynamical_trajectory_universal_unkwn_dT_vel_scld_data.h"
#include "rt_nonfinite.h"
#include "warning.h"
#include "xdhseqr.h"
#include "xnrm2.h"
#include "xscal.h"
#include "xzlarf.h"
#include "lapacke.h"
#include "mwmathutil.h"
#include <stddef.h>
#include <string.h>

/* Variable Definitions */
static emlrtRSInfo y_emlrtRSI = {
    35,      /* lineNo */
    "schur", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m" /* pathName
                                                                         */
};

static emlrtRSInfo ab_emlrtRSI = {
    66,      /* lineNo */
    "schur", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m" /* pathName
                                                                         */
};

static emlrtRSInfo bb_emlrtRSI = {
    69,      /* lineNo */
    "schur", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m" /* pathName
                                                                         */
};

static emlrtRSInfo cb_emlrtRSI = {
    70,      /* lineNo */
    "schur", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m" /* pathName
                                                                         */
};

static emlrtRSInfo db_emlrtRSI = {
    83,      /* lineNo */
    "schur", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m" /* pathName
                                                                         */
};

static emlrtRSInfo eb_emlrtRSI = {
    18,       /* lineNo */
    "xgehrd", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgehrd.m" /* pathName */
};

static emlrtRSInfo fb_emlrtRSI = {
    31,        /* lineNo */
    "xzgehrd", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "reflapack\\xzgehrd.m" /* pathName */
};

static emlrtRSInfo gb_emlrtRSI = {
    35,        /* lineNo */
    "xzgehrd", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "reflapack\\xzgehrd.m" /* pathName */
};

static emlrtRSInfo hb_emlrtRSI = {
    43,        /* lineNo */
    "xzgehrd", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "reflapack\\xzgehrd.m" /* pathName */
};

static emlrtRSInfo ib_emlrtRSI = {
    20,        /* lineNo */
    "xzlarfg", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "reflapack\\xzlarfg.m" /* pathName */
};

static emlrtRSInfo jb_emlrtRSI = {
    41,        /* lineNo */
    "xzlarfg", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "reflapack\\xzlarfg.m" /* pathName */
};

static emlrtRSInfo kb_emlrtRSI = {
    53,        /* lineNo */
    "xzlarfg", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "reflapack\\xzlarfg.m" /* pathName */
};

static emlrtRSInfo lb_emlrtRSI = {
    68,        /* lineNo */
    "xzlarfg", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "reflapack\\xzlarfg.m" /* pathName */
};

static emlrtRSInfo nb_emlrtRSI = {
    81,        /* lineNo */
    "xzlarfg", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "reflapack\\xzlarfg.m" /* pathName */
};

static emlrtRSInfo sb_emlrtRSI = {
    84,       /* lineNo */
    "xzlarf", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "reflapack\\xzlarf.m" /* pathName */
};

static emlrtRSInfo tb_emlrtRSI = {
    91,       /* lineNo */
    "xzlarf", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "reflapack\\xzlarf.m" /* pathName */
};

static emlrtRSInfo vb_emlrtRSI = {
    58,      /* lineNo */
    "xgemv", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "refblas\\xgemv.m" /* pathName */
};

static emlrtRSInfo ic_emlrtRSI = {
    11,          /* lineNo */
    "xungorghr", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xungorghr.m" /* pathName */
};

static emlrtRSInfo jc_emlrtRSI = {
    69,                /* lineNo */
    "ceval_xungorghr", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xungorghr.m" /* pathName */
};

static emlrtRSInfo kc_emlrtRSI = {
    21,       /* lineNo */
    "xhseqr", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xhseqr.m" /* pathName */
};

static emlrtRSInfo lc_emlrtRSI = {
    11,        /* lineNo */
    "xdhseqr", /* fcnName */
    "C:\\Program "
    "Files\\MATLAB\\R2021b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "reflapack\\xdhseqr.m" /* pathName */
};

/* Function Definitions */
void schur(const emlrtStack *sp, real_T A[16], real_T V[16])
{
  static const char_T fname[14] = {'L', 'A', 'P', 'A', 'C', 'K', 'E',
                                   '_', 'd', 'o', 'r', 'g', 'h', 'r'};
  ptrdiff_t info_t;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  emlrtStack g_st;
  emlrtStack h_st;
  emlrtStack i_st;
  emlrtStack st;
  real_T work[4];
  real_T tau[3];
  real_T b_alpha1_tmp;
  real_T xnorm;
  int32_T alpha1_tmp;
  int32_T b;
  int32_T b_i;
  int32_T exitg1;
  int32_T i;
  int32_T ia;
  int32_T iac;
  int32_T ic0;
  int32_T im1n_tmp_tmp;
  int32_T in;
  int32_T j;
  int32_T knt;
  int32_T lastc;
  int32_T lastv;
  boolean_T b_p;
  boolean_T exitg2;
  boolean_T p;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &y_emlrtRSI;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  g_st.prev = &f_st;
  g_st.tls = f_st.tls;
  h_st.prev = &g_st;
  h_st.tls = g_st.tls;
  i_st.prev = &h_st;
  i_st.tls = h_st.tls;
  if (anyNonFinite(A)) {
    for (j = 0; j < 16; j++) {
      V[j] = rtNaN;
    }
    i = 2;
    for (j = 0; j < 3; j++) {
      if (i <= 4) {
        memset(&V[(j * 4 + i) + -1], 0, (-i + 5) * sizeof(real_T));
      }
      i++;
    }
    for (j = 0; j < 16; j++) {
      A[j] = rtNaN;
    }
  } else {
    st.site = &ab_emlrtRSI;
    b_st.site = &eb_emlrtRSI;
    work[0] = 0.0;
    work[1] = 0.0;
    work[2] = 0.0;
    work[3] = 0.0;
    for (b_i = 0; b_i < 3; b_i++) {
      im1n_tmp_tmp = b_i << 2;
      in = (b_i + 1) << 2;
      alpha1_tmp = (b_i + im1n_tmp_tmp) + 1;
      b_alpha1_tmp = A[alpha1_tmp];
      i = b_i + 3;
      i = muIntScalarMin_sint32(i, 4) + im1n_tmp_tmp;
      c_st.site = &fb_emlrtRSI;
      tau[b_i] = 0.0;
      d_st.site = &ib_emlrtRSI;
      xnorm = xnrm2(&d_st, 2 - b_i, A, i);
      if (xnorm != 0.0) {
        xnorm = muDoubleScalarHypot(b_alpha1_tmp, xnorm);
        if (b_alpha1_tmp >= 0.0) {
          xnorm = -xnorm;
        }
        if (muDoubleScalarAbs(xnorm) < 1.0020841800044864E-292) {
          knt = 0;
          do {
            knt++;
            d_st.site = &jb_emlrtRSI;
            xscal(&d_st, 2 - b_i, 9.9792015476736E+291, A, i);
            xnorm *= 9.9792015476736E+291;
            b_alpha1_tmp *= 9.9792015476736E+291;
          } while (!(muDoubleScalarAbs(xnorm) >= 1.0020841800044864E-292));
          d_st.site = &kb_emlrtRSI;
          xnorm = xnrm2(&d_st, 2 - b_i, A, i);
          xnorm = muDoubleScalarHypot(b_alpha1_tmp, xnorm);
          if (b_alpha1_tmp >= 0.0) {
            xnorm = -xnorm;
          }
          tau[b_i] = (xnorm - b_alpha1_tmp) / xnorm;
          d_st.site = &lb_emlrtRSI;
          xscal(&d_st, 2 - b_i, 1.0 / (b_alpha1_tmp - xnorm), A, i);
          d_st.site = &mb_emlrtRSI;
          if ((1 <= knt) && (knt > 2147483646)) {
            e_st.site = &w_emlrtRSI;
            check_forloop_overflow_error(&e_st);
          }
          for (i = 0; i < knt; i++) {
            xnorm *= 1.0020841800044864E-292;
          }
          b_alpha1_tmp = xnorm;
        } else {
          tau[b_i] = (xnorm - A[alpha1_tmp]) / xnorm;
          d_st.site = &nb_emlrtRSI;
          xscal(&d_st, 2 - b_i, 1.0 / (A[(b_i + (b_i << 2)) + 1] - xnorm), A,
                i);
          b_alpha1_tmp = xnorm;
        }
      }
      A[alpha1_tmp] = 1.0;
      ic0 = in + 1;
      c_st.site = &gb_emlrtRSI;
      if (tau[b_i] != 0.0) {
        lastv = 2 - b_i;
        i = (alpha1_tmp - b_i) + 2;
        while ((lastv + 1 > 0) && (A[i] == 0.0)) {
          lastv--;
          i--;
        }
        lastc = 4;
        exitg2 = false;
        while ((!exitg2) && (lastc > 0)) {
          knt = in + lastc;
          ia = knt;
          do {
            exitg1 = 0;
            if (ia <= knt + (lastv << 2)) {
              if (A[ia - 1] != 0.0) {
                exitg1 = 1;
              } else {
                ia += 4;
              }
            } else {
              lastc--;
              exitg1 = 2;
            }
          } while (exitg1 == 0);
          if (exitg1 == 1) {
            exitg2 = true;
          }
        }
      } else {
        lastv = -1;
        lastc = 0;
      }
      if (lastv + 1 > 0) {
        d_st.site = &sb_emlrtRSI;
        e_st.site = &ub_emlrtRSI;
        if (lastc != 0) {
          f_st.site = &wb_emlrtRSI;
          if (0 <= lastc - 1) {
            memset(&work[0], 0, lastc * sizeof(real_T));
          }
          knt = alpha1_tmp;
          j = (in + (lastv << 2)) + 1;
          for (iac = ic0; iac <= j; iac += 4) {
            b = (iac + lastc) - 1;
            f_st.site = &vb_emlrtRSI;
            for (ia = iac; ia <= b; ia++) {
              i = ia - iac;
              work[i] += A[ia - 1] * A[knt];
            }
            knt++;
          }
        }
        d_st.site = &tb_emlrtRSI;
        e_st.site = &xb_emlrtRSI;
        f_st.site = &yb_emlrtRSI;
        g_st.site = &ac_emlrtRSI;
        if (!(-tau[b_i] == 0.0)) {
          knt = in;
          h_st.site = &bc_emlrtRSI;
          for (j = 0; j <= lastv; j++) {
            xnorm = A[alpha1_tmp + j];
            if (xnorm != 0.0) {
              xnorm *= -tau[b_i];
              i = knt + 1;
              b = lastc + knt;
              h_st.site = &cc_emlrtRSI;
              if ((knt + 1 <= b) && (b > 2147483646)) {
                i_st.site = &w_emlrtRSI;
                check_forloop_overflow_error(&i_st);
              }
              for (ic0 = i; ic0 <= b; ic0++) {
                A[ic0 - 1] += work[(ic0 - knt) - 1] * xnorm;
              }
            }
            knt += 4;
          }
        }
      }
      c_st.site = &hb_emlrtRSI;
      xzlarf(&c_st, 3 - b_i, 3 - b_i, (b_i + im1n_tmp_tmp) + 2, tau[b_i], A,
             (b_i + in) + 2, work);
      A[alpha1_tmp] = b_alpha1_tmp;
    }
    st.site = &bb_emlrtRSI;
    memcpy(&V[0], &A[0], 16U * sizeof(real_T));
    b_st.site = &ic_emlrtRSI;
    info_t = LAPACKE_dorghr(102, (ptrdiff_t)4, (ptrdiff_t)1, (ptrdiff_t)4,
                            &V[0], (ptrdiff_t)4, &tau[0]);
    i = (int32_T)info_t;
    c_st.site = &jc_emlrtRSI;
    if (i != 0) {
      p = true;
      b_p = false;
      if (i == -5) {
        b_p = true;
      } else if (i == -7) {
        b_p = true;
      }
      if (!b_p) {
        if (i == -1010) {
          emlrtErrorWithMessageIdR2018a(&c_st, &e_emlrtRTEI, "MATLAB:nomem",
                                        "MATLAB:nomem", 0);
        } else {
          emlrtErrorWithMessageIdR2018a(
              &c_st, &f_emlrtRTEI, "Coder:toolbox:LAPACKCallErrorInfo",
              "Coder:toolbox:LAPACKCallErrorInfo", 5, 4, 14, &fname[0], 12, i);
        }
      }
    } else {
      p = false;
    }
    if (p) {
      for (j = 0; j < 16; j++) {
        V[j] = rtNaN;
      }
    }
    st.site = &cb_emlrtRSI;
    b_st.site = &kc_emlrtRSI;
    c_st.site = &lc_emlrtRSI;
    i = eml_dlahqr(&c_st, A, V);
    A[3] = 0.0;
    if (i != 0) {
      st.site = &db_emlrtRSI;
      warning(&st);
    }
  }
}

/* End of code generation (schur.c) */
